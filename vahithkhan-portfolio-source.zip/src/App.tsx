import { useEffect, useState } from 'react'
import { startPointerTracking } from './lib/pointer'
import { Loader } from './components/Loader'
import { Background } from './components/Background'
import { Cursor } from './components/Cursor'
import { ScrollProgress } from './components/ScrollProgress'
import { Nav } from './components/Nav'
import { Hero } from './components/Hero'
import { About } from './components/About'
import { Skills } from './components/Skills'
import { Projects } from './components/Projects'
import { Timeline } from './components/Timeline'
import { Certificates } from './components/Certificates'
import { Contact } from './components/Contact'
import { Footer } from './components/Footer'

export default function App() {
  const [ready, setReady] = useState(false)

  useEffect(() => {
    startPointerTracking()
  }, [])

  // Keep the page still while the loader is up.
  useEffect(() => {
    document.documentElement.style.overflow = ready ? '' : 'hidden'
  }, [ready])

  return (
    <>
      <a href="#main" className="skip-link">
        Skip to content
      </a>
      <Loader onDone={() => setReady(true)} />
      <Background />
      <Cursor />
      <ScrollProgress />
      <Nav />
      <main id="main">
        <Hero ready={ready} />
        <About />
        <Skills />
        <Projects />
        <Timeline />
        <Certificates />
        <Contact />
      </main>
      <Footer />
    </>
  )
}
