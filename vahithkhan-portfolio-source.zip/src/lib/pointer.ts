/**
 * One shared, normalised pointer (-1..1 across the viewport). The 3D scene reads it every frame
 * without React re-renders. Touch drags update it too, so phones get some movement as well.
 */
export const pointer = { x: 0, y: 0 }

let started = false
export function startPointerTracking() {
  if (started || typeof window === 'undefined') return
  started = true
  window.addEventListener(
    'pointermove',
    (e) => {
      pointer.x = (e.clientX / window.innerWidth) * 2 - 1
      pointer.y = (e.clientY / window.innerHeight) * 2 - 1
    },
    { passive: true },
  )
}
