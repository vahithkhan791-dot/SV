/**
 * ALL CONTENT LIVES HERE. Edit this file to change text, add projects or add certificates.
 * Nothing on the site shows a number or claim that is not derived from these lists.
 */

export const profile = {
  name: 'Vahithkhan K',
  location: 'Tamil Nadu, India',
  email: 'vahithkhan143@gmail.com',
  github: 'https://github.com/vahithkhan791-dot',
  linkedin: 'https://www.linkedin.com/in/vahithkhan-k-0a4376390',
  roles: ['AI/ML Developer', 'Generative AI Developer', 'Python Developer'],
}

/* ---------------------------------- Skills ---------------------------------- */

export type SkillGroup = {
  id: string
  title: string
  icon: 'Brain' | 'Code2' | 'Sparkles' | 'Wrench'
  color: string
  items: string[]
}

export const skillGroups: SkillGroup[] = [
  {
    id: 'ai',
    title: 'AI & Machine Learning',
    icon: 'Brain',
    color: '#6C93FF',
    items: ['Python', 'Machine Learning', 'Deep Learning', 'Neural Networks', 'Generative AI', 'LLMs', 'RAG'],
  },
  {
    id: 'dev',
    title: 'Development',
    icon: 'Code2',
    color: '#A78BFA',
    items: ['Java', 'HTML', 'CSS', 'JavaScript', 'TypeScript', 'Python Backend'],
  },
  {
    id: 'ai-tools',
    title: 'AI Tools',
    icon: 'Sparkles',
    color: '#22D3EE',
    items: ['Claude', 'Gemini', 'Google AI Studio', 'LangChain', 'n8n', 'Zapier', 'Cursor', 'Codex'],
  },
  {
    id: 'dev-tools',
    title: 'Developer Tools',
    icon: 'Wrench',
    color: '#6C93FF',
    items: ['Git', 'GitHub', 'VS Code', 'PyCharm', 'MySQL', 'Jupyter Notebook'],
  },
]

/* --------------------------------- Projects --------------------------------- */

export type Project = {
  id: string
  title: string
  summary: string[]
  tags: string[]
  /** true for machine learning / AI projects. Drives the "AI/ML Projects" number. */
  ai: boolean
  /** Honest status label shown on the card. */
  status?: string
  visual?: 'radar' | 'match'
  /** Add real links only when you have them. A button appears automatically. */
  repo?: string
  live?: string
  /** Add a screenshot path (for example 'images/projects/foundit.webp') and it shows on the card. */
  image?: string
}

export const featuredProjects: Project[] = [
  {
    id: 'malware',
    title: 'Automated Malware Attack Detection System',
    summary: [
      'AI-powered malicious URL detection.',
      'Real-time security analysis.',
      'Malicious-link warning and protection concept.',
    ],
    tags: ['Machine Learning', 'URL Analysis', 'Cybersecurity'],
    ai: true,
    status: 'Prototype',
    visual: 'radar',
  },
  {
    id: 'foundit',
    title: 'FoundIt: AI-Powered Lost & Found System',
    summary: [
      'Intelligent lost and found matching.',
      'NLP-based description analysis.',
      'Smart item matching.',
    ],
    tags: ['NLP', 'Matching', 'AI'],
    ai: true,
    status: 'Prototype',
    visual: 'match',
  },
]

export const moreProjects: Project[] = [
  {
    id: 'hemocheck',
    title: 'HemoCheck',
    summary: [
      'Explainable AI for blood clot detection and risk assessment. EfficientNet-B0, ResNet-50 and EfficientNet-B2 read CT, MRI and ultrasound images, an XGBoost and Random Forest model scores risk, and Grad-CAM and SHAP show why. Exports PDF reports and runs on Streamlit Cloud.',
    ],
    tags: ['Python', 'PyTorch', 'XGBoost', 'SHAP', 'Grad-CAM', 'Streamlit'],
    ai: true,
  },
  {
    id: 'bureaucracy',
    title: 'AI Bureaucracy Help',
    summary: [
      'An assistant that simplifies government processes with document analysis, OCR-based data extraction and automated guidance for citizens.',
    ],
    tags: ['Python', 'LLM', 'RAG', 'OCR'],
    ai: true,
  },
  {
    id: 'traffic',
    title: 'Traffic Sign Recognition',
    summary: [
      'A CNN-based computer vision system that classifies road signs in real time, relevant to autonomous driving and driver assistance.',
    ],
    tags: ['Python', 'OpenCV', 'TensorFlow'],
    ai: true,
  },
  {
    id: 'fakenews',
    title: 'Fake News Detection',
    summary: ['A machine learning model that classifies news articles as real or fake using NLP text classification with TF-IDF features.'],
    tags: ['Python', 'ML', 'NLP'],
    ai: true,
  },
  {
    id: 'calories',
    title: 'AI Calories Calculator',
    summary: ['An estimator that predicts calorie intake from food inputs using machine learning, to support nutrition and diet tracking.'],
    tags: ['Python', 'ML', 'Flask'],
    ai: true,
  },
  {
    id: 'sports',
    title: 'Sports Booking AI App',
    summary: ['A sports court booking platform with real-time slot management, a conflict-prevention algorithm, JWT authentication and REST API endpoints.'],
    tags: ['Node.js', 'JavaScript', 'SQL', 'JWT'],
    ai: false,
  },
  {
    id: 'exam',
    title: 'Online Examination System',
    summary: ['A web-based exam platform with timed tests, automated evaluation, real-time results and secure user management.'],
    tags: ['Python', 'MySQL'],
    ai: false,
  },
  {
    id: 'freelancer',
    title: 'Freelancer Platform',
    summary: ['A marketplace where clients post projects and freelancers bid, with messaging, profile management and payment integration.'],
    tags: ['Node.js', 'React', 'MongoDB'],
    ai: false,
  },
  {
    id: 'music',
    title: 'Music Streaming App',
    summary: ['A streaming app with playlist management, audio playback controls, dynamic search and music API integration.'],
    tags: ['JavaScript', 'React', 'REST API'],
    ai: false,
  },
  {
    id: 'marketing',
    title: 'Digital Marketing Management',
    summary: ['A dashboard for planning and optimising campaigns across SEO, SEM, SMO and SMM channels, with performance analytics.'],
    tags: ['SEO', 'SEM', 'Analytics'],
    ai: false,
  },
]

/* ----------------------------- Experience & education ----------------------------- */

export type TimelineItem = {
  id: string
  type: 'education' | 'internship'
  title: string
  org: string
  period: string
  detail?: string
  points: string[]
}

export const timeline: TimelineItem[] = [
  {
    id: 'education',
    type: 'education',
    title: 'B.E. Computer Science and Engineering (AI & ML)',
    org: "St. Anne's College of Engineering and Technology",
    period: 'Expected graduation 2027',
    detail: 'CGPA 7.9',
    points: [
      'Final-year engineering student specialising in Artificial Intelligence and Machine Learning.',
    ],
  },
  {
    id: 'codenatives',
    type: 'internship',
    title: 'AI & ML Intern',
    org: 'Code Natives · Valasaravakkam, Chennai · On-site',
    period: 'Jun 6 – Jul 6, 2026',
    points: [
      'Completed a 30-day on-site internship built around hands-on project work with a dedicated engineering team.',
      'Built and iterated on an end-to-end machine learning project: data preprocessing, model development and evaluation under mentor guidance.',
      'Worked inside a professional software company, practising team-based development workflows.',
    ],
  },
  {
    id: 'adroit',
    type: 'internship',
    title: 'Generative AI Intern',
    org: 'AdroIT Technologies · Oracle University and Naan Mudhalvan Initiative · Online',
    period: 'Oct 8 – 23, 2025',
    points: [
      "Completed an intensive Generative AI programme covering LLMs, RAG architectures and prompt engineering under Oracle University's framework.",
      'Built AI-powered solutions for document processing and information retrieval, with exposure to LLM integration and deployment strategies.',
    ],
  },
  {
    id: 'codtech',
    type: 'internship',
    title: 'Figma App Development Intern',
    org: 'CODTECH IT Solutions Pvt. Ltd. · Online',
    period: 'Jul – Aug 2025',
    points: [
      'Designed end-to-end UI/UX prototypes for mobile and web apps in Figma, including wireframes, component libraries and design tokens.',
      'Applied user-centred design principles and was recognised for creativity, technical proficiency and problem-solving.',
      'Turned product requirements into production-ready interfaces that follow accessibility and responsive design standards.',
    ],
  },
]

/* ----------------------------- Certificates & achievements ----------------------------- */

export type Cert = {
  id: string
  title: string
  issuer: string
  kind: 'certification' | 'achievement' | 'internship' | 'event'
  date?: string
  featured?: boolean
  /** Add a certificate image later, for example 'images/certs/oci-ai.webp' (place it in public/). */
  image?: string
  /** Add a verification link later. A "Verify" button appears automatically. */
  verifyUrl?: string
}

export const certs: Cert[] = [
  { id: 'oci-ai', title: 'OCI 2025 Certified AI Foundations Associate', issuer: 'Oracle Cloud Infrastructure', kind: 'certification', featured: true },
  { id: 'oci-found', title: 'OCI 2025 Certified Foundations Associate', issuer: 'Oracle Cloud Infrastructure', kind: 'certification', featured: true },
  { id: 'genai-intern', title: 'Generative AI Internship Program', issuer: 'AdroIT Technologies · Oracle University · Naan Mudhalvan', kind: 'internship', date: 'Oct 2025', featured: true },
  { id: 'figma-intern', title: 'Figma App Development Internship', issuer: 'CODTECH IT Solutions', kind: 'internship', date: 'Jul – Aug 2025', featured: true },
  { id: 'sparcadeus', title: 'First Prize: Project Expo, SPARCADEUS 2K24', issuer: 'Dhanalakshmi Srinivasan College of Engineering & Technology, Chennai', kind: 'achievement', date: '2024', featured: true },
  { id: 'mathsday', title: 'First Place: Science Project Expo, National Mathematics Day', issuer: "St. Anne's CET · recognised by the National Council for Science & Technology Communication, Govt. of India", kind: 'achievement', date: '2024', featured: true },
  { id: 'hackathon', title: 'GUVI × HCL Hackathon, Participant', issuer: 'National-level hackathon on AI and software development', kind: 'achievement' },
  { id: 'naan-ach', title: 'Certificate of Achievement', issuer: 'Naan Mudhalvan · Tamil Nadu Skill Development Corporation', kind: 'certification', date: 'Oct 2025' },
  { id: 'aws-genai', title: 'Introduction to Generative AI', issuer: 'AWS', kind: 'certification' },
  { id: 'nvidia-genai', title: 'Generative AI Explained', issuer: 'NVIDIA', kind: 'certification' },
  { id: 'dl-nn', title: 'Neural Networks and Deep Learning', issuer: 'DeepLearning.AI', kind: 'certification' },
  { id: 'dl-py', title: 'AI Python for Beginners', issuer: 'DeepLearning.AI', kind: 'certification' },
  { id: 'alison-pe', title: 'The Fundamentals of Prompt Engineering for AI Models', issuer: 'Alison', kind: 'certification' },
  { id: 'tcs-ai', title: 'AI and Machine Learning Fundamentals', issuer: 'TCS iON', kind: 'certification' },
  { id: 'google-cloud', title: 'Google Cloud Engineering Certificate', issuer: 'Google', kind: 'certification' },
  { id: 'tf', title: 'Describe Infrastructure with Terraform', issuer: 'Microsoft + Code; Without Barriers', kind: 'certification' },
  { id: 'meta-be', title: 'Introduction to Back-End Development', issuer: 'Meta', kind: 'certification' },
  { id: 'ibm-py', title: 'Python for Data Science', issuer: 'IBM', kind: 'certification' },
  { id: 'ms-py', title: 'Introduction to Python Fundamentals', issuer: 'Microsoft', kind: 'certification' },
  { id: 'skillup-py', title: 'Programming with Python 3.X', issuer: 'SkillUp', kind: 'certification' },
  { id: 'besant-py', title: 'Programming with Python 3.X', issuer: 'Besant Technologies', kind: 'certification' },
  { id: 'gl-py', title: 'Python', issuer: 'Great Learning', kind: 'certification' },
  { id: 'guvi-figma', title: 'Mastering Figma: Beginner to Expert UI/UX Design', issuer: 'GUVI | HCL', kind: 'certification', date: 'Oct 2025' },
  { id: 'saylor-r', title: 'Introduction to R Programming (grade 86.96%)', issuer: 'Saylor Academy', kind: 'certification', date: 'Nov 2025' },
  { id: 'ml-psych', title: 'Human Psychology', issuer: 'Mind Luster', kind: 'certification' },
  { id: 'ml-robots', title: 'Coding with Programmable Robots for Beginners', issuer: 'Mind Luster', kind: 'certification', date: 'Jan 2025' },
  { id: 'alison-aml', title: 'Anti Money Laundering', issuer: 'Alison', kind: 'certification' },
  { id: 'srm-quiz', title: "Tech Quiz, CYNEX'26 National Symposium", issuer: 'SRM Institute of Science and Technology', kind: 'event', date: 'Sep 2026' },
  { id: 'digimonk', title: 'DigiMonk AI Summit 2026, Participation', issuer: 'DigiMonk Group', kind: 'event', date: 'Aug 2026' },
  { id: 'be10x', title: 'AI Tools and ChatGPT Workshop', issuer: 'be10x', kind: 'event', date: 'Oct 2026' },
]

/* ------------------------------- Verified numbers ------------------------------- */

export const stats = {
  aiProjects: [...featuredProjects, ...moreProjects].filter((p) => p.ai).length,
  technologies: new Set(skillGroups.flatMap((g) => g.items)).size,
  certifications: certs.filter((c) => c.kind === 'certification').length,
  internships: timeline.filter((t) => t.type === 'internship').length,
}
