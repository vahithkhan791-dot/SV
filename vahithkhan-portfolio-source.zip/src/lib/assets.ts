/** Resolve a file in /public relative to wherever the site is hosted. */
export const asset = (path: string) => `${import.meta.env.BASE_URL}${path.replace(/^\//, '')}`

export const AVATAR = {
  webp: asset('images/vahithkhan-3d-avatar.webp'),
  webpSmall: asset('images/vahithkhan-3d-avatar-480.webp'),
  png: asset('images/vahithkhan-3d-avatar.png'),
  width: 845,
  height: 1860,
}
export const RESUME_URL = asset('Vahithkhan_K_Resume.pdf')
