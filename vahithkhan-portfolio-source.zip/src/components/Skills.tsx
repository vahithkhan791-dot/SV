import type { CSSProperties } from 'react'
import { Brain, Code2, Sparkles, Wrench } from 'lucide-react'
import { skillGroups } from '../lib/data'
import { Reveal, Section, SectionHeading } from './Section'
import { Tilt } from './Tilt'

const icons = { Brain, Code2, Sparkles, Wrench }

export function Skills() {
  return (
    <Section id="skills">
      <SectionHeading
        eyebrow="Technical skills"
        title={
          <>
            The tools I <span className="gradient-text">build with</span>
          </>
        }
        sub="Hover a card to feel the depth. Every item below is something I have used in a project, internship or course."
      />
      <div className="grid gap-5 md:grid-cols-2">
        {skillGroups.map((g, i) => {
          const Icon = icons[g.icon]
          return (
            <Reveal key={g.id} delay={i * 0.07}>
              <Tilt color={g.color} className="glass accent-card h-full rounded-3xl p-6 sm:p-7">
                <div className="flex items-center gap-4">
                  <span
                    className="anim-bob grid h-12 w-12 shrink-0 place-items-center rounded-2xl"
                    style={
                      {
                        color: g.color,
                        background: `color-mix(in srgb, ${g.color} 14%, transparent)`,
                        boxShadow: `0 0 30px -6px ${g.color}`,
                        animationDelay: `${i * 0.4}s`,
                      } as CSSProperties
                    }
                  >
                    <Icon size={24} aria-hidden="true" />
                  </span>
                  <h3 className="h-display text-xl">{g.title}</h3>
                </div>
                <ul className="mt-6 flex flex-wrap gap-2.5">
                  {g.items.map((s) => (
                    <li
                      key={s}
                      className="cursor-default rounded-xl border px-3.5 py-2 text-sm text-fg transition duration-200 hover:-translate-y-0.5"
                      style={{
                        borderColor: `color-mix(in srgb, ${g.color} 30%, transparent)`,
                        background: `color-mix(in srgb, ${g.color} 7%, transparent)`,
                      }}
                    >
                      {s}
                    </li>
                  ))}
                </ul>
              </Tilt>
            </Reveal>
          )
        })}
      </div>
    </Section>
  )
}
