import { useEffect, useRef, useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { AVATAR } from '../lib/assets'
import { usePrefersReducedMotion } from '../lib/hooks'

const C = 2 * Math.PI * 54

/** Waits for the portrait and fonts (max 3.5s), shows a minimum of about 1.3s so it never flashes. */
export function Loader({ onDone }: { onDone: () => void }) {
  const reduce = usePrefersReducedMotion()
  const [progress, setProgress] = useState(0)
  const [visible, setVisible] = useState(true)
  const readyRef = useRef(false)
  const doneRef = useRef(onDone)
  doneRef.current = onDone

  useEffect(() => {
    let cancelled = false
    const portrait = new Promise<void>((res) => {
      const img = new Image()
      img.onload = img.onerror = () => res()
      img.src = AVATAR.webpSmall
    })
    const fonts: Promise<unknown> = document.fonts?.ready ?? Promise.resolve()
    const timeout = new Promise<void>((res) => setTimeout(res, 3500))
    Promise.race([Promise.all([portrait, fonts]), timeout]).then(() => {
      readyRef.current = true
    })

    const start = performance.now()
    const minMs = reduce ? 300 : 1300
    let p = 0
    let raf = 0
    const tick = (now: number) => {
      const t = Math.min(1, (now - start) / minMs)
      const target = readyRef.current ? 100 : 92
      p = Math.max(p, Math.min(target, t * 100))
      setProgress(Math.round(p))
      if (p >= 100) {
        setTimeout(() => {
          if (cancelled) return
          setVisible(false)
          doneRef.current()
        }, 220)
        return
      }
      raf = requestAnimationFrame(tick)
    }
    raf = requestAnimationFrame(tick)
    return () => {
      cancelled = true
      cancelAnimationFrame(raf)
    }
  }, [reduce])

  return (
    <AnimatePresence>
      {visible && (
        <motion.div
          key="loader"
          role="status"
          aria-label="Loading portfolio"
          className="fixed inset-0 z-[100] flex flex-col items-center justify-center bg-ink-950"
          exit={{ opacity: 0, scale: 1.04 }}
          transition={{ duration: 0.6, ease: 'easeInOut' }}
        >
          <div className="relative h-36 w-36">
            <svg viewBox="0 0 120 120" className="absolute inset-0 h-full w-full -rotate-90" aria-hidden="true">
              <defs>
                <linearGradient id="loader-grad" x1="0" y1="0" x2="1" y2="1">
                  <stop offset="0" stopColor="#4f7cff" />
                  <stop offset="0.6" stopColor="#8b5cf6" />
                  <stop offset="1" stopColor="#22d3ee" />
                </linearGradient>
              </defs>
              <circle cx="60" cy="60" r="54" fill="none" stroke="rgba(255,255,255,.08)" strokeWidth="3" />
              <circle
                cx="60"
                cy="60"
                r="54"
                fill="none"
                stroke="url(#loader-grad)"
                strokeWidth="3"
                strokeLinecap="round"
                strokeDasharray={C}
                strokeDashoffset={C * (1 - progress / 100)}
              />
            </svg>
            <div className="anim-spin-slow absolute inset-4 rounded-full border border-dashed border-neon-blue/30" aria-hidden="true" />
            <div className="absolute inset-0 grid place-items-center font-display text-3xl font-bold text-fg">VK</div>
          </div>
          <p className="mt-8 font-mono text-[11px] tracking-[0.3em] text-soft-blue">INITIALIZING NEURAL INTERFACE</p>
          <p aria-hidden="true" className="mt-2 font-mono text-sm tabular-nums text-mute">
            {progress}%
          </p>
        </motion.div>
      )}
    </AnimatePresence>
  )
}
