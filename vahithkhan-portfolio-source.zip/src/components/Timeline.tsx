import { useEffect, useRef } from 'react'
import { motion } from 'framer-motion'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'
import { Briefcase, GraduationCap } from 'lucide-react'
import { timeline } from '../lib/data'
import { usePrefersReducedMotion } from '../lib/hooks'
import { Section, SectionHeading } from './Section'

gsap.registerPlugin(ScrollTrigger)

export function Timeline() {
  const listRef = useRef<HTMLOListElement>(null)
  const lineRef = useRef<HTMLDivElement>(null)
  const reduce = usePrefersReducedMotion()

  // The glowing line draws itself as you scroll through the list.
  useEffect(() => {
    if (!lineRef.current || !listRef.current) return
    if (reduce) {
      gsap.set(lineRef.current, { scaleY: 1 })
      return
    }
    const ctx = gsap.context(() => {
      gsap.fromTo(
        lineRef.current,
        { scaleY: 0 },
        {
          scaleY: 1,
          ease: 'none',
          scrollTrigger: { trigger: listRef.current, start: 'top 70%', end: 'bottom 70%', scrub: 0.4 },
        },
      )
    }, listRef)
    return () => ctx.revert()
  }, [reduce])

  return (
    <Section id="experience">
      <SectionHeading
        eyebrow="Experience & education"
        title={
          <>
            Where I have <span className="gradient-text">learned and worked</span>
          </>
        }
      />
      <ol ref={listRef} className="relative mx-auto max-w-4xl">
        <div className="absolute bottom-2 left-[19px] top-2 w-px bg-white/10 md:left-1/2" aria-hidden="true" />
        <div
          ref={lineRef}
          className="absolute bottom-2 left-[19px] top-2 w-px origin-top md:left-1/2"
          style={{ background: 'linear-gradient(#4f7cff, #8b5cf6, #22d3ee)', boxShadow: '0 0 14px rgba(79,124,255,.8)' }}
          aria-hidden="true"
        />
        {timeline.map((t, i) => {
          const left = i % 2 === 0
          const Icon = t.type === 'education' ? GraduationCap : Briefcase
          return (
            <li key={t.id} className="relative pb-10 pl-14 last:pb-0 md:grid md:grid-cols-2 md:gap-14 md:pl-0">
              <span
                className="absolute left-0 top-1 grid h-10 w-10 place-items-center rounded-full border border-neon-blue/60 bg-ink-900 text-neon-cyan shadow-[0_0_22px_-4px_rgba(79,124,255,.9)] md:left-1/2 md:-translate-x-1/2"
                aria-hidden="true"
              >
                <Icon size={18} />
              </span>
              <motion.div
                initial={{ opacity: 0, x: left ? -40 : 40 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true, amount: 0.2 }}
                transition={{ duration: 0.7, ease: [0.2, 0.8, 0.2, 1] }}
                className={`glass rounded-2xl p-5 sm:p-6 ${left ? 'md:col-start-1 md:text-right' : 'md:col-start-2'}`}
              >
                <p className="font-mono text-xs tracking-wide text-neon-cyan">{t.period}</p>
                <h3 className="h-display mt-2 text-xl leading-snug">{t.title}</h3>
                <p className="mt-1 text-sm text-mute">{t.org}</p>
                {t.detail && <p className="mt-1 font-mono text-xs text-soft-blue">{t.detail}</p>}
                <ul className={`mt-4 space-y-2 text-sm text-mute ${left ? 'md:text-left' : ''}`}>
                  {t.points.map((p) => (
                    <li key={p} className="flex gap-2.5">
                      <span className="mt-2 h-1 w-1 shrink-0 rounded-full bg-neon-blue" aria-hidden="true" />
                      {p}
                    </li>
                  ))}
                </ul>
              </motion.div>
            </li>
          )
        })}
      </ol>
    </Section>
  )
}
