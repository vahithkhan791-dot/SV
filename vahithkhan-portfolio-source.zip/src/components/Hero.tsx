import { motion } from 'framer-motion'
import { ArrowDownRight, Download, Github, Linkedin, Mail, Send } from 'lucide-react'
import { profile } from '../lib/data'
import { RESUME_URL } from '../lib/assets'
import HeroPortrait from './HeroPortrait'

const ease = [0.2, 0.8, 0.2, 1] as const
const container = { hidden: {}, show: { transition: { staggerChildren: 0.09, delayChildren: 0.15 } } }
const rise = { hidden: { opacity: 0, y: 24 }, show: { opacity: 1, y: 0, transition: { duration: 0.7, ease } } }
const wordUp = { hidden: { y: '112%' }, show: { y: 0, transition: { duration: 0.85, ease } } }

function Line({ words, gradient = false }: { words: string[]; gradient?: boolean }) {
  return (
    <span className="block">
      {words.map((w) => (
        <span key={w}>
          <span className="inline-block overflow-hidden whitespace-nowrap pb-[0.12em] align-bottom">
            <motion.span variants={wordUp} className={`inline-block ${gradient ? 'gradient-text' : ''}`}>
              {w}
            </motion.span>
          </span>{' '}
        </span>
      ))}
    </span>
  )
}

export function Hero({ ready }: { ready: boolean }) {
  return (
    <section id="home" className="relative flex min-h-[100svh] items-center overflow-x-clip pb-6 pt-24 lg:pb-14 lg:pt-20">
      <div className="container-x grid items-center gap-8 lg:grid-cols-[1.08fr_0.92fr] lg:gap-4">
        <motion.div variants={container} initial="hidden" animate={ready ? 'show' : 'hidden'} className="min-w-0">
          <motion.div variants={rise}>
            <span className="glass inline-flex items-center gap-2.5 rounded-full px-3.5 py-1.5 font-mono text-[11px] tracking-[0.16em] text-fg">
              <span className="anim-pulse-dot h-2 w-2 rounded-full bg-neon-cyan" aria-hidden="true" />
              OPEN TO OPPORTUNITIES
            </span>
          </motion.div>

          <h1 className="h-display mt-6 text-[clamp(2.3rem,5.2vw,4.4rem)] uppercase leading-[0.98] tracking-[-0.02em]">
            <Line words={['Building', 'Intelligence.']} />
            <Line words={['Designing', 'the Future.']} gradient />
          </h1>

          <motion.p variants={rise} className="mt-6 max-w-xl text-base text-mute md:text-lg">
            I'm <span className="font-semibold text-fg">Vahithkhan K.</span> An AI/ML Developer passionate about building
            intelligent applications, automation systems and next-generation AI experiences.
          </motion.p>

          <motion.ul variants={rise} className="mt-5 flex flex-wrap gap-2" aria-label="Roles">
            {profile.roles.map((r) => (
              <li key={r} className="chip">
                {r}
              </li>
            ))}
          </motion.ul>

          <motion.div variants={rise} className="mt-8 flex flex-wrap gap-3">
            <a href="#projects" className="btn btn-primary">
              Explore My Work <ArrowDownRight size={18} aria-hidden="true" />
            </a>
            <a href={RESUME_URL} download="Vahithkhan_K_Resume.pdf" className="btn btn-ghost">
              <Download size={17} aria-hidden="true" /> Download Resume
            </a>
            <a href="#contact" className="btn btn-ghost">
              <Send size={16} aria-hidden="true" /> Contact Me
            </a>
          </motion.div>

          <motion.div variants={rise} className="mt-8 flex items-center gap-3">
            {[
              { href: profile.github, label: 'GitHub profile', Icon: Github },
              { href: profile.linkedin, label: 'LinkedIn profile', Icon: Linkedin },
              { href: `mailto:${profile.email}`, label: 'Send an email', Icon: Mail },
            ].map(({ href, label, Icon }) => (
              <a
                key={label}
                href={href}
                aria-label={label}
                {...(href.startsWith('http') ? { target: '_blank', rel: 'noopener noreferrer' } : {})}
                className="glass grid h-11 w-11 place-items-center rounded-xl text-mute transition hover:-translate-y-0.5 hover:border-neon-cyan/60 hover:text-fg"
              >
                <Icon size={18} aria-hidden="true" />
              </a>
            ))}
            <span className="ml-1 font-mono text-xs text-mute">{profile.location}</span>
          </motion.div>
        </motion.div>

        <HeroPortrait ready={ready} />
      </div>

      <a
        href="#about"
        aria-label="Scroll to About"
        className="absolute bottom-5 left-1/2 hidden -translate-x-1/2 flex-col items-center gap-2 font-mono text-[10px] tracking-[0.3em] text-mute transition hover:text-fg lg:flex"
      >
        SCROLL
        <span className="h-8 w-px bg-gradient-to-b from-neon-cyan to-transparent" aria-hidden="true" />
      </a>
    </section>
  )
}
