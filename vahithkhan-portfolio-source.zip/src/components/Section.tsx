import type { ReactNode } from 'react'
import { motion } from 'framer-motion'

export function Reveal({
  children,
  className = '',
  delay = 0,
}: {
  children: ReactNode
  className?: string
  delay?: number
}) {
  return (
    <motion.div
      className={className}
      initial={{ opacity: 0, y: 28 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, amount: 0.12 }}
      transition={{ duration: 0.7, delay, ease: [0.2, 0.8, 0.2, 1] }}
    >
      {children}
    </motion.div>
  )
}

export function SectionHeading({
  eyebrow,
  title,
  sub,
}: {
  eyebrow: string
  title: ReactNode
  sub?: string
}) {
  return (
    <div className="mb-10 max-w-3xl md:mb-14">
      <p className="eyebrow">{eyebrow}</p>
      <h2 className="h-display mt-3 text-[clamp(1.9rem,4.4vw,3.2rem)] leading-[1.08] [text-wrap:balance]">{title}</h2>
      {sub && <p className="mt-4 max-w-2xl text-base text-mute md:text-lg">{sub}</p>}
    </div>
  )
}

export function Section({
  id,
  children,
  className = '',
}: {
  id: string
  children: ReactNode
  className?: string
}) {
  return (
    <section id={id} className={`relative scroll-mt-16 overflow-x-clip py-20 md:py-28 ${className}`}>
      <div className="container-x">{children}</div>
    </section>
  )
}
