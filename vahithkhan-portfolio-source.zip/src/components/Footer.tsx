import { ArrowUp } from 'lucide-react'

export function Footer() {
  return (
    <footer className="border-t border-white/10 py-8">
      <div className="container-x flex flex-wrap items-center justify-between gap-4 text-sm text-mute">
        <p>© 2026 Vahithkhan K. Built with React, Three.js and Framer Motion.</p>
        <a href="#home" className="inline-flex min-h-[44px] items-center gap-2 rounded-lg px-2 hover:text-fg">
          Back to top <ArrowUp size={16} aria-hidden="true" />
        </a>
      </div>
    </footer>
  )
}
