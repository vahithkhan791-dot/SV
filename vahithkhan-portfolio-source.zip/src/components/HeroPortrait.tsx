import { Component, lazy, Suspense, useEffect, useMemo, useRef, useState, type ReactNode } from 'react'
import { motion, useMotionValue, useSpring, useTransform } from 'framer-motion'
import { Brain, Code2, Cpu, Network, Sparkles } from 'lucide-react'
import { AVATAR } from '../lib/assets'
import { hasWebGL, isLowEndDevice, useMediaQuery, usePrefersReducedMotion } from '../lib/hooks'
import StaticNetwork from './StaticNetwork'

const NeuralScene = lazy(() => import('./NeuralScene'))

class SceneBoundary extends Component<{ fallback: ReactNode; children: ReactNode }, { failed: boolean }> {
  state = { failed: false }
  static getDerivedStateFromError() {
    return { failed: true }
  }
  componentDidCatch(): void {}
  render() {
    return this.state.failed ? this.props.fallback : this.props.children
  }
}

const chips = [
  { label: 'LLMs', Icon: Brain, pos: 'left-[1%] top-[9%]', delay: 0, mobile: true },
  { label: 'RAG', Icon: Network, pos: 'right-[0%] top-[24%]', delay: 0.9, mobile: true },
  { label: 'Python', Icon: Code2, pos: 'left-[0%] top-[50%]', delay: 1.6, mobile: false },
  { label: 'Gen AI', Icon: Sparkles, pos: 'right-[1%] top-[60%]', delay: 0.5, mobile: true },
  { label: 'Deep Learning', Icon: Cpu, pos: 'left-[2%] top-[76%]', delay: 1.2, mobile: false },
]

function PortraitFallback() {
  return (
    <div
      role="img"
      aria-label="Portrait unavailable. Monogram VK."
      className="grid h-full w-full place-items-center bg-gradient-to-b from-ink-800 to-ink-950"
    >
      <div className="text-center">
        <p className="gradient-text font-display text-7xl font-bold">VK</p>
        <p className="mt-3 font-mono text-xs tracking-widest text-mute">VAHITHKHAN K</p>
      </div>
    </div>
  )
}

export default function HeroPortrait({ ready }: { ready: boolean }) {
  const reduce = usePrefersReducedMotion()
  const mobile = useMediaQuery('(max-width: 767px)')
  const wrapRef = useRef<HTMLDivElement>(null)
  const [visible, setVisible] = useState(true)
  const [imgFailed, setImgFailed] = useState(false)
  const can3D = useMemo(() => hasWebGL() && !isLowEndDevice(), [])
  const use3D = can3D && !reduce

  const mx = useMotionValue(0)
  const my = useMotionValue(0)
  useEffect(() => {
    if (reduce) return
    const on = (e: PointerEvent) => {
      mx.set((e.clientX / window.innerWidth) * 2 - 1)
      my.set((e.clientY / window.innerHeight) * 2 - 1)
    }
    window.addEventListener('pointermove', on, { passive: true })
    return () => window.removeEventListener('pointermove', on)
  }, [reduce, mx, my])

  const sx = useSpring(mx, { stiffness: 60, damping: 16, mass: 0.6 })
  const sy = useSpring(my, { stiffness: 60, damping: 16, mass: 0.6 })
  const rotateY = useTransform(sx, [-1, 1], [-11, 11])
  const rotateX = useTransform(sy, [-1, 1], [7, -7])
  const glowX = useTransform(sx, [-1, 1], [30, -30])
  const glowY = useTransform(sy, [-1, 1], [20, -20])
  const chipX = useTransform(sx, [-1, 1], [-22, 22])
  const chipY = useTransform(sy, [-1, 1], [-14, 14])

  useEffect(() => {
    const el = wrapRef.current
    if (!el) return
    const io = new IntersectionObserver(([e]) => setVisible(e.isIntersecting), { threshold: 0 })
    io.observe(el)
    return () => io.disconnect()
  }, [])

  return (
    <div ref={wrapRef} className="relative flex items-center justify-center py-2">
      {/* neural network behind the portrait */}
      <div className="pointer-events-none absolute inset-x-[-14%] inset-y-[-4%]" aria-hidden="true">
        {use3D ? (
          <SceneBoundary fallback={<StaticNetwork />}>
            <Suspense fallback={<StaticNetwork />}>
              <NeuralScene mobile={mobile} active={visible} />
            </Suspense>
          </SceneBoundary>
        ) : (
          <StaticNetwork animated={!reduce} />
        )}
      </div>

      {/* blue and purple neon light, moves opposite to the pointer for depth */}
      <motion.div aria-hidden="true" className="pointer-events-none absolute inset-0" style={{ x: glowX, y: glowY }}>
        <div className="absolute left-[8%] top-[18%] h-[46%] w-[58%] rounded-full bg-neon-blue/30 blur-[70px]" />
        <div className="absolute bottom-[10%] right-[6%] h-[44%] w-[54%] rounded-full bg-neon-violet/30 blur-[80px]" />
      </motion.div>

      <motion.div
        className="relative z-10"
        style={{ rotateX, rotateY, transformPerspective: 1000 }}
        initial={{ opacity: 0, y: 50, scale: 0.96 }}
        animate={ready ? { opacity: 1, y: 0, scale: 1 } : undefined}
        transition={{ duration: 1, ease: [0.2, 0.8, 0.2, 1], delay: 0.2 }}
      >
        <div className="anim-float">
          <div className="portrait-frame">
            <div className="portrait-glow">
              <div className="portrait-mask">
                {imgFailed ? (
                  <PortraitFallback />
                ) : (
                  <picture>
                    <source
                      type="image/webp"
                      srcSet={`${AVATAR.webpSmall} 480w, ${AVATAR.webp} 845w`}
                      sizes="(max-width: 1023px) 260px, 340px"
                    />
                    <img
                      src={AVATAR.png}
                      width={AVATAR.width}
                      height={AVATAR.height}
                      alt="Vahithkhan K standing in a black suit and white shirt"
                      decoding="async"
                      draggable={false}
                      onError={() => setImgFailed(true)}
                      className="block h-full w-full select-none"
                      {...({ fetchpriority: 'high' } as Record<string, string>)}
                    />
                  </picture>
                )}
                <div className="portrait-tint" aria-hidden="true" />
              </div>
            </div>
          </div>
        </div>
      </motion.div>

      {/* floating AI technology chips */}
      {chips.map(({ label, Icon, pos, delay, mobile: showOnMobile }) => (
        <motion.div
          key={label}
          aria-hidden="true"
          className={`absolute z-20 ${pos} ${showOnMobile ? '' : 'hidden sm:block'}`}
          style={{ x: chipX, y: chipY }}
          initial={{ opacity: 0, scale: 0.8 }}
          animate={ready ? { opacity: 1, scale: 1 } : undefined}
          transition={{ duration: 0.6, delay: 0.9 + delay * 0.2 }}
        >
          <div
            className="glass anim-bob flex items-center gap-2 rounded-full px-3 py-1.5 font-mono text-[11px] text-fg shadow-[0_0_24px_-6px_rgba(79,124,255,.7)]"
            style={{ animationDelay: `${delay}s` }}
          >
            <Icon size={14} className="text-neon-cyan" />
            {label}
          </div>
        </motion.div>
      ))}
    </div>
  )
}
