import { useEffect, useState } from 'react'
import { motion, useMotionValue, useSpring } from 'framer-motion'
import { useMediaQuery, usePrefersReducedMotion } from '../lib/hooks'

/** Soft light and a small ring that follow a mouse. The real cursor stays visible. Not rendered on touch or reduced motion. */
export function Cursor() {
  const fine = useMediaQuery('(pointer: fine)')
  const reduce = usePrefersReducedMotion()
  const x = useMotionValue(-200)
  const y = useMotionValue(-200)
  const gx = useSpring(x, { stiffness: 120, damping: 20, mass: 0.6 })
  const gy = useSpring(y, { stiffness: 120, damping: 20, mass: 0.6 })
  const rx = useSpring(x, { stiffness: 480, damping: 34, mass: 0.3 })
  const ry = useSpring(y, { stiffness: 480, damping: 34, mass: 0.3 })
  const [big, setBig] = useState(false)

  useEffect(() => {
    if (!fine || reduce) return
    const move = (e: PointerEvent) => {
      x.set(e.clientX)
      y.set(e.clientY)
    }
    const over = (e: PointerEvent) => {
      const t = e.target as Element | null
      setBig(!!t?.closest?.('a,button,[role="button"],input,textarea,.tilt'))
    }
    window.addEventListener('pointermove', move, { passive: true })
    window.addEventListener('pointerover', over, { passive: true })
    return () => {
      window.removeEventListener('pointermove', move)
      window.removeEventListener('pointerover', over)
    }
  }, [fine, reduce, x, y])

  if (!fine || reduce) return null
  return (
    <>
      <motion.div aria-hidden="true" className="cursor-glow" style={{ x: gx, y: gy }} />
      <motion.div aria-hidden="true" className="cursor-ring" style={{ x: rx, y: ry }} animate={{ scale: big ? 1.9 : 1, opacity: big ? 0.9 : 0.6 }} />
    </>
  )
}
