/** SVG neural network. Used for reduced motion, no WebGL, low-end phones and while the 3D scene downloads. */
function seeded(seed: number) {
  let s = seed
  return () => (s = (s * 16807) % 2147483647) / 2147483647
}

const rnd = seeded(11)
const NODES = Array.from({ length: 48 }, () => {
  const a = rnd() * Math.PI * 2
  const r = Math.sqrt(rnd())
  return { x: 200 + Math.cos(a) * r * 150, y: 175 + Math.sin(a) * r * 112, d: rnd() * 3, c: ['#6c93ff', '#a78bfa', '#22d3ee'][Math.floor(rnd() * 3)] }
})
const EDGES: [number, number][] = []
NODES.forEach((n, i) => {
  NODES.map((m, j) => ({ j, d: (n.x - m.x) ** 2 + (n.y - m.y) ** 2 }))
    .filter((o) => o.j !== i)
    .sort((a, b) => a.d - b.d)
    .slice(0, 2)
    .forEach((o) => EDGES.push([i, o.j]))
})

export default function StaticNetwork({ animated = true }: { animated?: boolean }) {
  return (
    <svg viewBox="0 0 400 350" className="h-full w-full" preserveAspectRatio="xMidYMid meet" aria-hidden="true" focusable="false">
      <defs>
        <radialGradient id="sn-glow" cx="50%" cy="50%" r="50%">
          <stop offset="0" stopColor="#4f7cff" stopOpacity="0.35" />
          <stop offset="0.6" stopColor="#8b5cf6" stopOpacity="0.12" />
          <stop offset="1" stopColor="#8b5cf6" stopOpacity="0" />
        </radialGradient>
      </defs>
      <ellipse cx="200" cy="175" rx="190" ry="160" fill="url(#sn-glow)" />
      <g stroke="#7c9bff" strokeOpacity="0.28" strokeWidth="1">
        {EDGES.map(([a, b], i) => (
          <line key={i} x1={NODES[a].x} y1={NODES[a].y} x2={NODES[b].x} y2={NODES[b].y} />
        ))}
      </g>
      {NODES.map((n, i) => (
        <circle
          key={i}
          cx={n.x}
          cy={n.y}
          r={2 + (i % 3)}
          fill={n.c}
          style={animated ? { animation: `node-pulse ${2.4 + n.d}s ease-in-out ${n.d}s infinite` } : undefined}
        />
      ))}
    </svg>
  )
}
