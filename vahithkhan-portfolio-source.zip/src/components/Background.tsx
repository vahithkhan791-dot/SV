/** Animated gradient background. Transform-only animation, so it stays cheap on laptops and phones. */
export function Background() {
  return (
    <div aria-hidden="true" className="pointer-events-none fixed inset-0 -z-10 overflow-hidden bg-ink-950">
      <div className="bg-blob anim-drift-a" style={{ width: '46vw', height: '46vw', left: '-12vw', top: '-10vw', background: '#2b45d6' }} />
      <div className="bg-blob anim-drift-b" style={{ width: '40vw', height: '40vw', right: '-10vw', top: '8vh', background: '#6d32e0', opacity: 0.42 }} />
      <div className="bg-blob anim-drift-a" style={{ width: '34vw', height: '34vw', left: '30vw', bottom: '-16vw', background: '#0e9fbd', opacity: 0.28 }} />
      <div className="bg-grid" />
      <div className="absolute inset-0" style={{ background: 'radial-gradient(ellipse at 50% 0%, transparent 40%, rgba(5,6,13,.65) 100%)' }} />
    </div>
  )
}
