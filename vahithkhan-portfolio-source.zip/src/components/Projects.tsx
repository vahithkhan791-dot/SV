import { ArrowUpRight, Brain, Code2, ExternalLink, Github, Search, ShieldAlert } from 'lucide-react'
import { featuredProjects, moreProjects, profile, type Project } from '../lib/data'
import { asset } from '../lib/assets'
import { Reveal, Section, SectionHeading } from './Section'
import { Tilt } from './Tilt'

function RadarVisual() {
  return (
    <div
      className="relative grid h-44 place-items-center overflow-hidden rounded-2xl border border-white/10"
      style={{ background: 'radial-gradient(circle at 50% 50%, rgba(34,211,238,.14), rgba(5,6,13,.9) 70%)' }}
      aria-hidden="true"
    >
      {[26, 52, 78, 104].map((s) => (
        <span key={s} className="absolute rounded-full border border-neon-cyan/20" style={{ width: s * 1.6, height: s * 1.6 }} />
      ))}
      <span
        className="absolute h-[168px] w-[168px] rounded-full"
        style={{ background: 'conic-gradient(from 0deg, transparent 0deg, transparent 290deg, rgba(34,211,238,.5) 360deg)', animation: 'sweep 4s linear infinite' }}
      />
      {[
        { l: '66%', t: '28%', d: '0s' },
        { l: '30%', t: '62%', d: '1.2s' },
        { l: '72%', t: '66%', d: '2.2s' },
      ].map((b) => (
        <span key={b.l} className="absolute h-2 w-2 rounded-full bg-red-400" style={{ left: b.l, top: b.t }}>
          <span className="absolute inset-0 rounded-full border border-red-400" style={{ animation: `ping-ring 2.6s ease-out ${b.d} infinite` }} />
        </span>
      ))}
      <ShieldAlert size={30} className="relative text-neon-cyan" />
    </div>
  )
}

function MatchVisual() {
  return (
    <div
      className="relative grid h-44 place-items-center overflow-hidden rounded-2xl border border-white/10"
      style={{ background: 'radial-gradient(circle at 50% 50%, rgba(139,92,246,.18), rgba(5,6,13,.9) 70%)' }}
      aria-hidden="true"
    >
      <svg viewBox="0 0 300 176" className="absolute inset-0 h-full w-full">
        <g stroke="#A78BFA" strokeOpacity="0.7" strokeWidth="1.5" strokeDasharray="6 6" style={{ animation: 'dash 1.2s linear infinite' }}>
          <line x1="60" y1="50" x2="150" y2="88" />
          <line x1="60" y1="130" x2="150" y2="88" />
          <line x1="240" y1="48" x2="150" y2="88" />
          <line x1="240" y1="132" x2="150" y2="88" />
        </g>
        {[[60, 50], [60, 130], [240, 48], [240, 132]].map(([x, y], i) => (
          <circle key={i} cx={x} cy={y} r="7" fill={i % 2 ? '#22D3EE' : '#6C93FF'} style={{ animation: `node-pulse 2.4s ease-in-out ${i * 0.5}s infinite` }} />
        ))}
      </svg>
      <span className="relative grid h-12 w-12 place-items-center rounded-full border border-soft-violet/60 bg-ink-900/80 text-soft-violet">
        <Search size={22} />
      </span>
    </div>
  )
}

function Links({ p }: { p: Project }) {
  if (!p.repo && !p.live) return null
  return (
    <div className="mt-5 flex flex-wrap gap-3">
      {p.repo && (
        <a href={p.repo} target="_blank" rel="noopener noreferrer" className="btn btn-ghost !min-h-[40px] !px-4">
          <Github size={16} aria-hidden="true" /> Code
        </a>
      )}
      {p.live && (
        <a href={p.live} target="_blank" rel="noopener noreferrer" className="btn btn-ghost !min-h-[40px] !px-4">
          <ExternalLink size={16} aria-hidden="true" /> Live
        </a>
      )}
    </div>
  )
}

function Featured({ p, color }: { p: Project; color: string }) {
  return (
    <Tilt color={color} className="glass accent-card flex h-full flex-col rounded-3xl p-5 sm:p-6">
      {p.image ? (
        <img src={asset(p.image)} alt={`${p.title} screenshot`} loading="lazy" className="h-44 w-full rounded-2xl border border-white/10 object-cover" />
      ) : p.visual === 'match' ? (
        <MatchVisual />
      ) : (
        <RadarVisual />
      )}
      <div className="mt-5 flex flex-wrap items-center gap-2">
        <span className="chip" style={{ color: '#7CE9F8', borderColor: 'rgba(34,211,238,.35)', background: 'rgba(34,211,238,.08)' }}>
          Featured
        </span>
        {p.status && <span className="chip">{p.status}</span>}
      </div>
      <h3 className="h-display mt-3 text-2xl leading-tight">{p.title}</h3>
      <ul className="mt-3 space-y-1.5 text-mute">
        {p.summary.map((s) => (
          <li key={s} className="flex gap-2.5">
            <span className="mt-2.5 h-1 w-1 shrink-0 rounded-full bg-neon-cyan" aria-hidden="true" />
            {s}
          </li>
        ))}
      </ul>
      <ul className="mt-5 flex flex-wrap gap-2" aria-label="Technologies">
        {p.tags.map((t) => (
          <li key={t} className="chip">
            {t}
          </li>
        ))}
      </ul>
      <Links p={p} />
    </Tilt>
  )
}

function Compact({ p }: { p: Project }) {
  const Icon = p.ai ? Brain : Code2
  const color = p.ai ? '#6C93FF' : '#A78BFA'
  return (
    <Tilt color={color} max={7} className="glass accent-card flex h-full flex-col rounded-2xl p-5">
      <div className="flex items-start justify-between gap-3">
        <span className="grid h-10 w-10 place-items-center rounded-xl" style={{ color, background: `color-mix(in srgb, ${color} 14%, transparent)` }}>
          <Icon size={20} aria-hidden="true" />
        </span>
        {p.ai && <span className="chip">AI/ML</span>}
      </div>
      <h3 className="h-display mt-4 text-lg leading-snug">{p.title}</h3>
      <p className="mt-2 text-sm text-mute">{p.summary[0]}</p>
      <ul className="mt-auto flex flex-wrap gap-1.5 pt-4" aria-label="Technologies">
        {p.tags.map((t) => (
          <li key={t} className="chip">
            {t}
          </li>
        ))}
      </ul>
      <Links p={p} />
    </Tilt>
  )
}

export function Projects() {
  return (
    <Section id="projects">
      <SectionHeading
        eyebrow="Featured projects"
        title={
          <>
            Things I have <span className="gradient-text">built</span>
          </>
        }
        sub="Prototypes are labelled as prototypes. Links appear on a card only when a real repository or demo is added."
      />
      <div className="grid gap-5 lg:grid-cols-2">
        {featuredProjects.map((p, i) => (
          <Reveal key={p.id} delay={i * 0.08}>
            <Featured p={p} color={i === 0 ? '#22D3EE' : '#A78BFA'} />
          </Reveal>
        ))}
      </div>

      <Reveal>
        <h3 className="h-display mb-6 mt-16 text-2xl">More projects</h3>
      </Reveal>
      <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
        {moreProjects.map((p, i) => (
          <Reveal key={p.id} delay={(i % 3) * 0.06}>
            <Compact p={p} />
          </Reveal>
        ))}
        <Reveal delay={0.1}>
          <a
            href={profile.github}
            target="_blank"
            rel="noopener noreferrer"
            className="group flex h-full min-h-[200px] flex-col items-center justify-center gap-3 rounded-2xl border border-dashed border-white/20 p-5 text-center text-mute transition hover:border-neon-cyan/60 hover:text-fg"
          >
            <Github size={26} aria-hidden="true" />
            <span className="font-display text-lg font-semibold text-fg">More on GitHub</span>
            <span className="inline-flex items-center gap-1 text-sm">
              New projects land here first <ArrowUpRight size={15} aria-hidden="true" className="transition group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
            </span>
          </a>
        </Reveal>
      </div>
    </Section>
  )
}
