import { useRef, type CSSProperties, type PointerEvent, type ReactNode } from 'react'
import { usePrefersReducedMotion } from '../lib/hooks'

type Props = {
  children: ReactNode
  className?: string
  /** Max tilt in degrees. */
  max?: number
  /** Accent colour used for the hover glare and border. */
  color?: string
}

/** CSS 3D tilt that follows the pointer. Disabled for touch input and reduced motion. */
export function Tilt({ children, className = '', max = 9, color }: Props) {
  const ref = useRef<HTMLDivElement>(null)
  const reduce = usePrefersReducedMotion()

  const move = (e: PointerEvent<HTMLDivElement>) => {
    const el = ref.current
    if (!el || reduce || e.pointerType === 'touch') return
    const r = el.getBoundingClientRect()
    const x = (e.clientX - r.left) / r.width
    const y = (e.clientY - r.top) / r.height
    el.style.setProperty('--rx', `${((0.5 - y) * max).toFixed(2)}deg`)
    el.style.setProperty('--ry', `${((x - 0.5) * max * 1.2).toFixed(2)}deg`)
    el.style.setProperty('--mx', `${(x * 100).toFixed(1)}%`)
    el.style.setProperty('--my', `${(y * 100).toFixed(1)}%`)
  }
  const leave = () => {
    const el = ref.current
    if (!el) return
    el.style.setProperty('--rx', '0deg')
    el.style.setProperty('--ry', '0deg')
  }

  const style = color ? ({ '--c': color } as CSSProperties) : undefined
  return (
    <div ref={ref} className={`tilt ${className}`} style={style} onPointerMove={move} onPointerLeave={leave}>
      <span className="tilt-glare" aria-hidden="true" />
      {children}
    </div>
  )
}
