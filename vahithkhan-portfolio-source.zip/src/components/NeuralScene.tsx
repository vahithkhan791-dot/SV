import { useMemo, useRef } from 'react'
import { Canvas, useFrame, useThree } from '@react-three/fiber'
import { Float } from '@react-three/drei'
import * as THREE from 'three'
import { pointer } from '../lib/pointer'

/* ---------- helpers ---------- */

function rng(seed: number) {
  let s = seed
  return () => (s = (s * 16807) % 2147483647) / 2147483647
}

function makeSprite() {
  const c = document.createElement('canvas')
  c.width = c.height = 64
  const g = c.getContext('2d')!
  const gr = g.createRadialGradient(32, 32, 0, 32, 32, 32)
  gr.addColorStop(0, 'rgba(255,255,255,1)')
  gr.addColorStop(0.3, 'rgba(255,255,255,.8)')
  gr.addColorStop(0.65, 'rgba(255,255,255,.15)')
  gr.addColorStop(1, 'rgba(255,255,255,0)')
  g.fillStyle = gr
  g.fillRect(0, 0, 64, 64)
  return new THREE.CanvasTexture(c)
}

const BLUE = new THREE.Color('#4F7CFF')
const VIOLET = new THREE.Color('#8B5CF6')
const CYAN = new THREE.Color('#22D3EE')

function colorAt(v: THREE.Vector3) {
  const t = THREE.MathUtils.clamp((v.x + 3) / 6, 0, 1)
  const c = BLUE.clone().lerp(VIOLET, t)
  return c.lerp(CYAN, THREE.MathUtils.clamp((v.y + 0.5) / 5, 0, 0.55))
}

/** Neurons spread over two hemispheres with a central fissure, joined to their nearest neighbours. */
function buildBrain(count: number) {
  const r = rng(2024)
  const pts: THREE.Vector3[] = []
  for (let i = 0; i < count; i++) {
    const th = r() * Math.PI * 2
    const ph = Math.acos(2 * r() - 1)
    let x = Math.sin(ph) * Math.cos(th)
    let y = Math.cos(ph)
    let z = Math.sin(ph) * Math.sin(th)
    const f = 0.74 + r() * 0.26
    const gyri = 1 + Math.sin(th * 7) * Math.sin(ph * 6) * 0.07
    x *= 3.0 * f * gyri
    y *= 2.3 * f * gyri
    z *= 2.4 * f * gyri
    if (y < 0) y *= 0.72
    x += (x >= 0 ? 1 : -1) * 0.22
    pts.push(new THREE.Vector3(x, y, z))
  }
  const edges: [number, number][] = []
  const seen = new Set<string>()
  for (let i = 0; i < count; i++) {
    const d: { j: number; d: number }[] = []
    for (let j = 0; j < count; j++) if (j !== i) d.push({ j, d: pts[i].distanceToSquared(pts[j]) })
    d.sort((a, b) => a.d - b.d)
    for (let k = 0; k < 3; k++) {
      const j = d[k].j
      const key = i < j ? `${i}-${j}` : `${j}-${i}`
      if (!seen.has(key)) {
        seen.add(key)
        edges.push([i, j])
      }
    }
  }
  return { pts, edges }
}

/* ---------- scene ---------- */

function Scene({ mobile }: { mobile: boolean }) {
  const size = useThree((s) => s.size)
  const root = useRef<THREE.Group>(null)
  const brainRef = useRef<THREE.Group>(null)
  const pulseGeo = useRef<THREE.BufferGeometry>(null)
  const light = useRef<THREE.PointLight>(null)
  const state = useRef({ angle: 0, px: 0, py: 0 })

  const sprite = useMemo(makeSprite, [])
  const { pts, edges } = useMemo(() => buildBrain(mobile ? 120 : 230), [mobile])

  const geo = useMemo(() => {
    const nodePos = new Float32Array(pts.length * 3)
    const nodeCol = new Float32Array(pts.length * 3)
    pts.forEach((p, i) => {
      nodePos.set([p.x, p.y, p.z], i * 3)
      const c = colorAt(p)
      nodeCol.set([c.r, c.g, c.b], i * 3)
    })
    const linePos = new Float32Array(edges.length * 6)
    const lineCol = new Float32Array(edges.length * 6)
    edges.forEach(([a, b], i) => {
      linePos.set([pts[a].x, pts[a].y, pts[a].z, pts[b].x, pts[b].y, pts[b].z], i * 6)
      const ca = colorAt(pts[a])
      const cb = colorAt(pts[b])
      lineCol.set([ca.r, ca.g, ca.b, cb.r, cb.g, cb.b], i * 6)
    })
    const rr = rng(99)
    const dustN = mobile ? 120 : 260
    const dust = new Float32Array(dustN * 3)
    for (let i = 0; i < dustN; i++) {
      const rad = 4.2 + rr() * 4
      const th = rr() * Math.PI * 2
      const ph = Math.acos(2 * rr() - 1)
      dust.set([rad * Math.sin(ph) * Math.cos(th), rad * Math.cos(ph) * 0.8, rad * Math.sin(ph) * Math.sin(th) - 1], i * 3)
    }
    return { nodePos, nodeCol, linePos, lineCol, dust }
  }, [pts, edges, mobile])

  const pulses = useMemo(() => {
    const r = rng(7)
    return Array.from({ length: mobile ? 16 : 34 }, () => ({ e: Math.floor(r() * edges.length), t: r(), v: 0.25 + r() * 0.4 }))
  }, [edges, mobile])
  const pulsePos = useMemo(() => new Float32Array(pulses.length * 3), [pulses])

  const aspect = size.width / Math.max(1, size.height)
  const viewW = 6.91 * aspect
  const scale = THREE.MathUtils.clamp(viewW / 7.6, 0.5, 1.05)

  useFrame((s, dt) => {
    const st = state.current
    st.angle += dt * 0.14
    st.px += (pointer.x - st.px) * Math.min(1, dt * 3)
    st.py += (pointer.y - st.py) * Math.min(1, dt * 3)
    const b = brainRef.current
    if (b) {
      b.rotation.y = st.angle + st.px * 0.5 + window.scrollY * 0.0009
      b.rotation.x = st.py * 0.22 + Math.sin(s.clock.elapsedTime * 0.4) * 0.04
    }
    if (light.current) {
      light.current.position.x += (st.px * 5 - light.current.position.x) * Math.min(1, dt * 4)
      light.current.position.y += (-st.py * 3.5 - light.current.position.y) * Math.min(1, dt * 4)
    }
    for (let i = 0; i < pulses.length; i++) {
      const q = pulses[i]
      q.t += q.v * dt
      if (q.t >= 1) {
        q.e = (q.e * 7 + 13 + i) % edges.length
        q.t = 0
      }
      const [a, c] = edges[q.e]
      const A = pts[a]
      const B = pts[c]
      pulsePos[i * 3] = A.x + (B.x - A.x) * q.t
      pulsePos[i * 3 + 1] = A.y + (B.y - A.y) * q.t
      pulsePos[i * 3 + 2] = A.z + (B.z - A.z) * q.t
    }
    if (pulseGeo.current) pulseGeo.current.attributes.position.needsUpdate = true
  })

  return (
    <group ref={root} scale={scale} position={[0, 0.8, 0]}>
      <ambientLight intensity={0.55} />
      <pointLight ref={light} position={[0, 0, 4]} intensity={70} distance={16} color="#8fb0ff" />
      <pointLight position={[-4, -2, 3]} intensity={45} distance={14} color="#8b5cf6" />

      <group ref={brainRef}>
        <points>
          <bufferGeometry>
            <bufferAttribute attach="attributes-position" count={pts.length} array={geo.nodePos} itemSize={3} />
            <bufferAttribute attach="attributes-color" count={pts.length} array={geo.nodeCol} itemSize={3} />
          </bufferGeometry>
          <pointsMaterial size={0.26} map={sprite} vertexColors transparent depthWrite={false} blending={THREE.AdditiveBlending} sizeAttenuation />
        </points>
        <lineSegments>
          <bufferGeometry>
            <bufferAttribute attach="attributes-position" count={edges.length * 2} array={geo.linePos} itemSize={3} />
            <bufferAttribute attach="attributes-color" count={edges.length * 2} array={geo.lineCol} itemSize={3} />
          </bufferGeometry>
          <lineBasicMaterial vertexColors transparent opacity={0.65} depthWrite={false} blending={THREE.AdditiveBlending} />
        </lineSegments>
        <points>
          <bufferGeometry ref={pulseGeo}>
            <bufferAttribute attach="attributes-position" count={pulses.length} array={pulsePos} itemSize={3} />
          </bufferGeometry>
          <pointsMaterial size={0.34} map={sprite} color="#b8f1ff" transparent depthWrite={false} blending={THREE.AdditiveBlending} sizeAttenuation />
        </points>
      </group>

      <points>
        <bufferGeometry>
          <bufferAttribute attach="attributes-position" count={geo.dust.length / 3} array={geo.dust} itemSize={3} />
        </bufferGeometry>
        <pointsMaterial size={0.09} map={sprite} color="#7c9bff" transparent opacity={0.55} depthWrite={false} blending={THREE.AdditiveBlending} sizeAttenuation />
      </points>

      {/* floating technology objects, lit by the pointer-following light */}
      <Float speed={1.3} rotationIntensity={1.2} floatIntensity={1.6}>
        <group position={[2.7, 1.8, 1.0]}>
          <mesh>
            <icosahedronGeometry args={[0.42, 0]} />
            <meshStandardMaterial color="#4F7CFF" metalness={0.85} roughness={0.25} emissive="#1c2fa8" emissiveIntensity={0.7} />
          </mesh>
          <mesh scale={1.5}>
            <icosahedronGeometry args={[0.42, 0]} />
            <meshBasicMaterial color="#7C9BFF" wireframe transparent opacity={0.35} />
          </mesh>
        </group>
      </Float>
      <Float speed={1.6} rotationIntensity={1.4} floatIntensity={1.4}>
        <mesh position={[-2.4, -1.5, 1.0]}>
          <torusGeometry args={[0.36, 0.12, 16, 40]} />
          <meshStandardMaterial color="#8B5CF6" metalness={0.8} roughness={0.28} emissive="#4a1fb5" emissiveIntensity={0.7} />
        </mesh>
      </Float>
      <Float speed={1.1} rotationIntensity={1.6} floatIntensity={1.8}>
        <group position={[2.7, -2.4, 0.6]}>
          <mesh>
            <octahedronGeometry args={[0.38, 0]} />
            <meshStandardMaterial color="#22D3EE" metalness={0.8} roughness={0.3} emissive="#0a7f99" emissiveIntensity={0.7} />
          </mesh>
          <mesh scale={1.55}>
            <octahedronGeometry args={[0.38, 0]} />
            <meshBasicMaterial color="#22D3EE" wireframe transparent opacity={0.3} />
          </mesh>
        </group>
      </Float>
      {!mobile && (
        <>
          <Float speed={1.5} rotationIntensity={1.1} floatIntensity={1.5}>
            <mesh position={[-2.5, 2.2, -0.4]}>
              <dodecahedronGeometry args={[0.34, 0]} />
              <meshBasicMaterial color="#A78BFA" wireframe />
            </mesh>
          </Float>
          <Float speed={1.2} rotationIntensity={1.8} floatIntensity={1.2}>
            <mesh position={[1.3, 2.4, 0.6]}>
              <torusKnotGeometry args={[0.22, 0.07, 80, 12]} />
              <meshStandardMaterial color="#4F7CFF" metalness={0.9} roughness={0.2} emissive="#1c2fa8" emissiveIntensity={0.5} />
            </mesh>
          </Float>
        </>
      )}
    </group>
  )
}

export default function NeuralScene({ mobile, active }: { mobile: boolean; active: boolean }) {
  return (
    <Canvas
      frameloop={active ? 'always' : 'never'}
      dpr={[1, mobile ? 1.25 : 1.6]}
      camera={{ position: [0, 0, 9], fov: 42 }}
      gl={{ alpha: true, antialias: !mobile, powerPreference: 'high-performance' }}
      onCreated={({ gl }) => gl.setClearColor(0x000000, 0)}
      style={{ pointerEvents: 'none' }}
    >
      <Scene mobile={mobile} />
    </Canvas>
  )
}
