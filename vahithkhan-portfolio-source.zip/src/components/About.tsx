import { useEffect, useRef, useState } from 'react'
import { useInView } from 'framer-motion'
import gsap from 'gsap'
import { Award, Brain, Briefcase, Cpu, MapPin, GraduationCap } from 'lucide-react'
import { profile, stats } from '../lib/data'
import { usePrefersReducedMotion } from '../lib/hooks'
import { Reveal, Section, SectionHeading } from './Section'
import { Tilt } from './Tilt'

function Counter({ to }: { to: number }) {
  const ref = useRef<HTMLSpanElement>(null)
  const inView = useInView(ref, { once: true, margin: '-10% 0px' })
  const reduce = usePrefersReducedMotion()
  const [v, setV] = useState(0)
  useEffect(() => {
    if (!inView) return
    if (reduce) {
      setV(to)
      return
    }
    const o = { n: 0 }
    const tween = gsap.to(o, { n: to, duration: 1.6, ease: 'power2.out', onUpdate: () => setV(Math.round(o.n)) })
    return () => {
      tween.kill()
    }
  }, [inView, to, reduce])
  return (
    <span ref={ref} aria-label={String(to)}>
      <span aria-hidden="true">{v}</span>
    </span>
  )
}

const items = [
  { label: 'AI/ML Projects', value: stats.aiProjects, Icon: Brain, color: '#6C93FF' },
  { label: 'Technologies', value: stats.technologies, Icon: Cpu, color: '#A78BFA' },
  { label: 'Certifications', value: stats.certifications, Icon: Award, color: '#22D3EE' },
  { label: 'Internships', value: stats.internships, Icon: Briefcase, color: '#6C93FF' },
]

export function About() {
  return (
    <Section id="about">
      <div className="grid items-center gap-12 lg:grid-cols-[1.1fr_0.9fr]">
        <Reveal>
          <SectionHeading
            eyebrow="About me"
            title={
              <>
                Turning ideas into <span className="gradient-text">intelligent applications</span>
              </>
            }
          />
          <div className="max-w-2xl space-y-5 text-base text-mute md:text-lg">
            <p>
              I'm an aspiring AI/ML Developer and final-year engineering student interested in Artificial Intelligence,
              Machine Learning, Generative AI, LLMs, RAG systems and intelligent automation.
            </p>
            <p>
              I enjoy transforming ideas into practical applications using modern AI technologies and software
              development tools.
            </p>
          </div>
          <ul className="mt-7 flex flex-wrap gap-x-6 gap-y-3 text-sm text-mute">
            <li className="flex items-center gap-2">
              <GraduationCap size={16} className="text-neon-cyan" aria-hidden="true" />
              B.E. CSE (AI &amp; ML), expected 2027
            </li>
            <li className="flex items-center gap-2">
              <MapPin size={16} className="text-neon-cyan" aria-hidden="true" />
              {profile.location}
            </li>
          </ul>
        </Reveal>

        <Reveal delay={0.1}>
          <div className="grid grid-cols-2 gap-4">
            {items.map(({ label, value, Icon, color }) => (
              <Tilt key={label} color={color} className="glass accent-card rounded-2xl p-5 sm:p-6">
                <Icon size={22} style={{ color }} aria-hidden="true" />
                <p className="h-display mt-4 text-4xl tabular-nums sm:text-5xl">
                  <Counter to={value} />
                </p>
                <p className="mt-1 text-sm text-mute">{label}</p>
              </Tilt>
            ))}
          </div>
          <p className="mt-4 font-mono text-[11px] text-mute">Counted from the lists on this page. Nothing is estimated.</p>
        </Reveal>
      </div>
    </Section>
  )
}
