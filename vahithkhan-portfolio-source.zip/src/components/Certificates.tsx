import { useEffect, useMemo, useRef, useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { Award, Briefcase, CalendarDays, ExternalLink, Trophy, X } from 'lucide-react'
import { certs, type Cert } from '../lib/data'
import { asset } from '../lib/assets'
import { Reveal, Section, SectionHeading } from './Section'
import { Tilt } from './Tilt'

type Filter = 'all' | Cert['kind']
const filters: { id: Filter; label: string }[] = [
  { id: 'all', label: 'All' },
  { id: 'certification', label: 'Certifications' },
  { id: 'achievement', label: 'Achievements' },
  { id: 'internship', label: 'Internships' },
  { id: 'event', label: 'Events' },
]

const kindMeta = {
  certification: { Icon: Award, color: '#6C93FF', label: 'Certification' },
  achievement: { Icon: Trophy, color: '#FBBF24', label: 'Achievement' },
  internship: { Icon: Briefcase, color: '#A78BFA', label: 'Internship' },
  event: { Icon: CalendarDays, color: '#22D3EE', label: 'Event' },
} as const

const INITIAL = 9

function Card({ c, onOpen }: { c: Cert; onOpen: (c: Cert) => void }) {
  const { Icon, color, label } = kindMeta[c.kind]
  const interactive = !!(c.image || c.verifyUrl)
  const body = (
    <>
      <div className="flex items-start gap-4">
        <span
          className="grid h-11 w-11 shrink-0 place-items-center rounded-xl"
          style={{ color, background: `color-mix(in srgb, ${color} 14%, transparent)`, boxShadow: `0 0 24px -8px ${color}` }}
        >
          <Icon size={20} aria-hidden="true" />
        </span>
        <div className="min-w-0 text-left">
          <h3 className="font-display text-[15.5px] font-semibold leading-snug text-fg">{c.title}</h3>
          <p className="mt-1 text-[13px] text-mute">{c.issuer}</p>
        </div>
      </div>
      <div className="mt-4 flex flex-wrap items-center gap-2">
        <span className="chip" style={{ color, borderColor: `color-mix(in srgb, ${color} 35%, transparent)` }}>
          {label}
        </span>
        {c.date && <span className="font-mono text-[11.5px] text-mute">{c.date}</span>}
        {interactive && <span className="ml-auto font-mono text-[11.5px] text-neon-cyan">View</span>}
      </div>
    </>
  )
  return (
    <Tilt color={color} max={6} className={`glass accent-card h-full rounded-2xl ${c.featured ? 'ring-1 ring-white/10' : ''}`}>
      {interactive ? (
        <button type="button" onClick={() => onOpen(c)} className="block h-full w-full cursor-pointer rounded-2xl p-5 text-left" aria-haspopup="dialog">
          {body}
        </button>
      ) : (
        <div className="h-full p-5">{body}</div>
      )}
    </Tilt>
  )
}

function Modal({ c, onClose }: { c: Cert; onClose: () => void }) {
  const closeRef = useRef<HTMLButtonElement>(null)
  const { color, label } = kindMeta[c.kind]
  useEffect(() => {
    closeRef.current?.focus()
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && onClose()
    window.addEventListener('keydown', onKey)
    document.documentElement.style.overflow = 'hidden'
    return () => {
      window.removeEventListener('keydown', onKey)
      document.documentElement.style.overflow = ''
    }
  }, [onClose])

  return (
    <motion.div
      className="fixed inset-0 z-[90] grid place-items-center bg-black/70 p-4 backdrop-blur-sm"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      onClick={onClose}
    >
      <motion.div
        role="dialog"
        aria-modal="true"
        aria-labelledby="cert-title"
        className="glass relative max-h-[88svh] w-full max-w-lg overflow-auto rounded-3xl bg-ink-900/90 p-6"
        initial={{ opacity: 0, y: 24, scale: 0.96 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        exit={{ opacity: 0, y: 24, scale: 0.96 }}
        transition={{ duration: 0.25 }}
        onClick={(e) => e.stopPropagation()}
      >
        <button ref={closeRef} type="button" onClick={onClose} aria-label="Close certificate" className="absolute right-4 top-4 grid h-10 w-10 cursor-pointer place-items-center rounded-xl border border-white/15 text-fg hover:bg-white/10">
          <X size={18} aria-hidden="true" />
        </button>
        <span className="chip" style={{ color }}>
          {label}
        </span>
        <h3 id="cert-title" className="h-display mt-3 pr-12 text-xl leading-snug">
          {c.title}
        </h3>
        <p className="mt-1 text-sm text-mute">
          {c.issuer}
          {c.date ? ` · ${c.date}` : ''}
        </p>
        {c.image && <img src={asset(c.image)} alt={`Certificate: ${c.title}`} loading="lazy" className="mt-5 w-full rounded-xl border border-white/10" />}
        {c.verifyUrl && (
          <a href={c.verifyUrl} target="_blank" rel="noopener noreferrer" className="btn btn-primary mt-5">
            <ExternalLink size={16} aria-hidden="true" /> Verify certificate
          </a>
        )}
      </motion.div>
    </motion.div>
  )
}

export function Certificates() {
  const [filter, setFilter] = useState<Filter>('all')
  const [expanded, setExpanded] = useState(false)
  const [open, setOpen] = useState<Cert | null>(null)

  const list = useMemo(() => {
    const base = filter === 'all' ? certs : certs.filter((c) => c.kind === filter)
    return [...base].sort((a, b) => Number(!!b.featured) - Number(!!a.featured))
  }, [filter])
  const shown = expanded ? list : list.slice(0, INITIAL)

  return (
    <Section id="certificates">
      <SectionHeading
        eyebrow="Certifications & achievements"
        title={
          <>
            Proof of <span className="gradient-text">learning and winning</span>
          </>
        }
      />
      <Reveal>
        <div role="group" aria-label="Filter certificates" className="mb-8 flex flex-wrap gap-2">
          {filters.map((f) => {
            const count = f.id === 'all' ? certs.length : certs.filter((c) => c.kind === f.id).length
            const active = filter === f.id
            return (
              <button
                key={f.id}
                type="button"
                aria-pressed={active}
                onClick={() => {
                  setFilter(f.id)
                  setExpanded(false)
                }}
                className={`min-h-[44px] cursor-pointer rounded-xl border px-4 text-sm font-medium transition ${
                  active ? 'border-neon-blue bg-neon-blue/15 text-fg' : 'border-white/15 text-mute hover:text-fg'
                }`}
              >
                {f.label} <span className="ml-1 font-mono text-xs opacity-70">{count}</span>
              </button>
            )
          })}
        </div>
      </Reveal>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {shown.map((c) => (
          <Card key={c.id} c={c} onOpen={setOpen} />
        ))}
      </div>

      {list.length > INITIAL && (
        <div className="mt-8 flex justify-center">
          <button type="button" onClick={() => setExpanded((e) => !e)} className="btn btn-ghost" aria-expanded={expanded}>
            {expanded ? 'Show fewer' : `Show all ${list.length}`}
          </button>
        </div>
      )}

      <AnimatePresence>{open && <Modal c={open} onClose={() => setOpen(null)} />}</AnimatePresence>
    </Section>
  )
}
