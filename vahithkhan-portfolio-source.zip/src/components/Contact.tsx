import { useState, type FormEvent } from 'react'
import { Check, Copy, Github, Linkedin, Loader2, Mail, Send } from 'lucide-react'
import { profile } from '../lib/data'
import { asset } from '../lib/assets'
import { Reveal, Section } from './Section'

type Values = { name: string; email: string; message: string }
type Errors = Partial<Record<keyof Values, string>>
type Status = 'idle' | 'sending' | 'sent' | 'mailto' | 'error'

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/

function validate(v: Values): Errors {
  const e: Errors = {}
  if (v.name.trim().length < 2) e.name = 'Enter your name (at least 2 characters).'
  if (!EMAIL_RE.test(v.email.trim())) e.email = 'Enter a valid email address, like name@example.com.'
  if (v.message.trim().length < 10) e.message = 'Write a message of at least 10 characters.'
  return e
}

/** Reads public/site-config.json at runtime, so the form can be switched on by editing one file with no rebuild. */
async function loadEndpoint(): Promise<string> {
  try {
    const res = await fetch(asset('site-config.json'), { cache: 'no-store' })
    if (!res.ok) return ''
    const cfg = (await res.json()) as { formEndpoint?: string }
    return (cfg.formEndpoint ?? '').trim()
  } catch {
    return ''
  }
}

const field =
  'w-full rounded-xl border bg-ink-950/60 px-4 py-3 text-base text-fg placeholder:text-mute/70 outline-none transition focus:border-neon-cyan focus:ring-2 focus:ring-neon-cyan/30'

export function Contact() {
  const [values, setValues] = useState<Values>({ name: '', email: '', message: '' })
  const [honey, setHoney] = useState('')
  const [errors, setErrors] = useState<Errors>({})
  const [status, setStatus] = useState<Status>('idle')
  const [copied, setCopied] = useState(false)

  const set = (k: keyof Values, v: string) => {
    const next = { ...values, [k]: v }
    setValues(next)
    // Re-check as you type, so a shown error disappears as soon as the field is valid.
    if (errors[k]) setErrors((e) => ({ ...e, [k]: validate(next)[k] }))
  }
  const blur = (k: keyof Values) => setErrors((e) => ({ ...e, [k]: validate(values)[k] }))

  const copyEmail = async () => {
    try {
      await navigator.clipboard.writeText(profile.email)
      setCopied(true)
      setTimeout(() => setCopied(false), 1800)
    } catch {
      /* clipboard blocked: the address is visible and selectable on the page */
    }
  }

  const onSubmit = async (ev: FormEvent) => {
    ev.preventDefault()
    if (honey) return // bots fill the hidden field
    const errs = validate(values)
    setErrors(errs)
    const first = (Object.keys(errs) as (keyof Values)[])[0]
    if (first) {
      document.getElementById(`c-${first}`)?.focus()
      return
    }
    setStatus('sending')
    const endpoint = await loadEndpoint()
    if (!endpoint) {
      const subject = encodeURIComponent(`Portfolio message from ${values.name.trim()}`)
      const body = encodeURIComponent(`${values.message.trim()}\n\n${values.name.trim()}\n${values.email.trim()}`)
      window.location.href = `mailto:${profile.email}?subject=${subject}&body=${body}`
      setStatus('mailto')
      return
    }
    try {
      const res = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
        body: JSON.stringify({ name: values.name.trim(), email: values.email.trim(), message: values.message.trim() }),
      })
      if (!res.ok) throw new Error(String(res.status))
      setStatus('sent')
      setValues({ name: '', email: '', message: '' })
    } catch {
      setStatus('error')
    }
  }

  return (
    <Section id="contact" className="overflow-hidden">
      <div aria-hidden="true" className="pointer-events-none absolute inset-0">
        <div className="anim-drift-a absolute left-[-10%] top-[10%] h-72 w-72 rounded-full bg-neon-blue/25 blur-[90px]" />
        <div className="anim-drift-b absolute bottom-[0%] right-[-8%] h-80 w-80 rounded-full bg-neon-violet/25 blur-[100px]" />
      </div>

      <div className="relative grid items-start gap-12 lg:grid-cols-[1fr_1fr]">
        <Reveal>
          <p className="eyebrow">Contact</p>
          <h2 className="h-display mt-3 text-[clamp(2rem,4.8vw,3.6rem)] uppercase leading-[1.04]">
            Have an idea? Let's build something <span className="gradient-text">intelligent.</span>
          </h2>
          <p className="mt-5 max-w-md text-mute md:text-lg">
            I am open to AI/ML internships and entry-level roles. The fastest way to reach me is email.
          </p>

          <ul className="mt-8 space-y-3">
            <li className="glass flex flex-wrap items-center gap-3 rounded-2xl p-4">
              <Mail size={20} className="text-neon-cyan" aria-hidden="true" />
              <a href={`mailto:${profile.email}`} className="min-w-0 break-all text-fg hover:underline">
                {profile.email}
              </a>
              <button type="button" onClick={copyEmail} className="ml-auto inline-flex min-h-[40px] cursor-pointer items-center gap-1.5 rounded-lg border border-white/15 px-3 text-xs text-mute hover:text-fg">
                {copied ? <Check size={14} aria-hidden="true" /> : <Copy size={14} aria-hidden="true" />}
                {copied ? 'Copied' : 'Copy'}
              </button>
            </li>
            <li>
              <a href={profile.linkedin} target="_blank" rel="noopener noreferrer" className="glass flex items-center gap-3 rounded-2xl p-4 text-fg transition hover:border-neon-blue/60">
                <Linkedin size={20} className="text-neon-cyan" aria-hidden="true" /> LinkedIn
                <span className="ml-auto truncate text-sm text-mute">vahithkhan-k-0a4376390</span>
              </a>
            </li>
            <li>
              <a href={profile.github} target="_blank" rel="noopener noreferrer" className="glass flex items-center gap-3 rounded-2xl p-4 text-fg transition hover:border-neon-blue/60">
                <Github size={20} className="text-neon-cyan" aria-hidden="true" /> GitHub
                <span className="ml-auto truncate text-sm text-mute">vahithkhan791-dot</span>
              </a>
            </li>
          </ul>
        </Reveal>

        <Reveal delay={0.1}>
          <form onSubmit={onSubmit} noValidate className="glass rounded-3xl p-6 sm:p-8" aria-label="Contact form">
            <div className="space-y-2">
              {(
                [
                  { k: 'name', label: 'Name', type: 'text', auto: 'name' },
                  { k: 'email', label: 'Email', type: 'email', auto: 'email' },
                ] as const
              ).map(({ k, label, type, auto }) => (
                <div key={k}>
                  <label htmlFor={`c-${k}`} className="mb-1.5 block text-sm font-medium text-fg">
                    {label}
                  </label>
                  <input
                    id={`c-${k}`}
                    name={k}
                    type={type}
                    autoComplete={auto}
                    value={values[k]}
                    onChange={(e) => set(k, e.target.value)}
                    onBlur={() => blur(k)}
                    aria-invalid={!!errors[k]}
                    aria-describedby={errors[k] ? `c-${k}-err` : undefined}
                    className={`${field} ${errors[k] ? 'border-red-400/70' : 'border-white/15'}`}
                  />
                  {/* space is always reserved so the form never jumps when an error appears or clears */}
                  <p id={`c-${k}-err`} className="mt-1.5 min-h-[1.25rem] text-sm text-red-300">
                    {errors[k]}
                  </p>
                </div>
              ))}
              <div>
                <label htmlFor="c-message" className="mb-1.5 block text-sm font-medium text-fg">
                  Message
                </label>
                <textarea
                  id="c-message"
                  name="message"
                  rows={5}
                  value={values.message}
                  onChange={(e) => set('message', e.target.value)}
                  onBlur={() => blur('message')}
                  aria-invalid={!!errors.message}
                  aria-describedby={errors.message ? 'c-message-err' : undefined}
                  className={`${field} resize-y ${errors.message ? 'border-red-400/70' : 'border-white/15'}`}
                />
                <p id="c-message-err" className="mt-1.5 min-h-[1.25rem] text-sm text-red-300">
                  {errors.message}
                </p>
              </div>
              {/* honeypot: hidden from people, filled by bots */}
              <div className="absolute -left-[9999px]" aria-hidden="true">
                <label htmlFor="c-company">Company</label>
                <input id="c-company" tabIndex={-1} autoComplete="off" value={honey} onChange={(e) => setHoney(e.target.value)} />
              </div>
              <button type="submit" disabled={status === 'sending'} className="btn btn-primary w-full disabled:cursor-wait disabled:opacity-70">
                {status === 'sending' ? <Loader2 size={18} className="animate-spin" aria-hidden="true" /> : <Send size={17} aria-hidden="true" />}
                {status === 'sending' ? 'Sending' : 'Send message'}
              </button>
            </div>

            <div aria-live="polite" className="mt-4 min-h-[1.5rem] text-sm">
              {status === 'sent' && <p className="text-emerald-300">Thanks. Your message was sent. I will reply by email.</p>}
              {status === 'mailto' && (
                <p className="text-soft-blue">
                  Your email app should open with the message ready to send. If nothing opens, write to{' '}
                  <a className="underline" href={`mailto:${profile.email}`}>
                    {profile.email}
                  </a>
                  . Nothing has been sent yet.
                </p>
              )}
              {status === 'error' && (
                <p className="text-red-300">
                  The message did not send. Please try again, or email{' '}
                  <a className="underline" href={`mailto:${profile.email}`}>
                    {profile.email}
                  </a>
                  .
                </p>
              )}
            </div>
          </form>
        </Reveal>
      </div>
    </Section>
  )
}
