# Vahithkhan K: 3D AI Developer Portfolio

React + Vite + TypeScript + Tailwind, with Three.js (React Three Fiber, Drei), Framer Motion, GSAP and Lucide icons.

## Deploy on GitHub Pages (no build needed)

Upload the **contents of the `dist` folder** (not the folder itself) to the root of your repo:

- `index.html`
- `assets/` (folder)
- `images/` (folder)
- `Vahithkhan_K_Resume.pdf`
- `site-config.json`

Then Settings, Pages, Deploy from branch `main`, folder `/ (root)`.

## Change content

Everything lives in `src/lib/data.ts`: profile links, skills, projects, timeline, certificates. The four numbers in the About section are counted from those lists, so they can never drift from the content.

- **Project link or screenshot:** add `repo`, `live` or `image` to a project. The button or picture appears on its own.
- **Certificate image or verify link:** add `image` (a file in `public/`) or `verifyUrl`. The card becomes clickable and opens a viewer.
- **Resume:** replace `public/Vahithkhan_K_Resume.pdf`.
- **Portrait:** replace `public/images/vahithkhan-3d-avatar.*` (keep the same names). The page expects a 845 x 1860 portrait. Another ratio needs `AVATAR` in `src/lib/assets.ts` and `aspect-ratio` in `src/index.css`.

## Turn on the contact form

Without setup, the form opens the visitor's email app with the message filled in, and tells them nothing has been sent yet.

To send messages straight to your inbox:

1. Create a free form at https://formspree.io and copy its URL (looks like `https://formspree.io/f/abcdwxyz`).
2. Edit `site-config.json` in your repo and paste it: `{ "formEndpoint": "https://formspree.io/f/abcdwxyz" }`.

No rebuild is needed. The file is read when the page loads.

## Run locally

```bash
npm install
npm run dev      # development
npm run build    # production build into dist/
```

## Accessibility and performance

- Reduced-motion setting: no WebGL, a still network drawing, no cursor effects, no tilt.
- No WebGL, or 2 CPU cores or fewer: the same still drawing.
- The 3D scene pauses when scrolled out of view. Mobile gets fewer nodes and a lower pixel ratio.
- Keyboard navigation, visible focus, skip link, labelled form fields with inline errors.
