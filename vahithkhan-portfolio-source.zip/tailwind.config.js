/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        ink: { 950: '#05060D', 900: '#080A14', 850: '#0B0E1A', 800: '#10142A' },
        neon: { blue: '#4F7CFF', violet: '#8B5CF6', cyan: '#22D3EE' },
        soft: { blue: '#7C9BFF', violet: '#A78BFA' },
        fg: '#E8ECFF',
        mute: '#9AA4C7',
      },
      fontFamily: {
        display: ['"Space Grotesk"', 'Inter', 'system-ui', 'sans-serif'],
        sans: ['Inter', 'system-ui', '-apple-system', 'Segoe UI', 'sans-serif'],
        mono: ['"JetBrains Mono"', 'ui-monospace', 'SFMono-Regular', 'Menlo', 'monospace'],
      },
    },
  },
  plugins: [],
}
